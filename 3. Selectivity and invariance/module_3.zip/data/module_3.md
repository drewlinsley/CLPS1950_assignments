Download data from: https://www.dropbox.com/sh/2fjo4hj2d7cnul7/AACNl9OYIUGFCHnyOTJgM2IJa?dl=0
Place data in this folder (`~/data`).
The full path should be: `~/3. Selectivity and invariance/data/*`

