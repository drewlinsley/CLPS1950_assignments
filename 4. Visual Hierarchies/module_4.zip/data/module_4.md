Download data from: https://www.dropbox.com/sh/pl77mybvjs4zlra/AAB0Yvn6S9_PWkMXREacCTaAa?dl=0
Place data in this folder (`~/data`).
The full path should be: `~/4. Visual hierarchies/data/*`

