Download data from: https://www.dropbox.com/sh/rv32u1hjjcw7e8i/AAC4h79imnDVUmfYjNeMizHba?dl=0
Place data in this folder (`~/data`).
The full path should be: `~/2. Multi-layer Neural Networks/data/*`
